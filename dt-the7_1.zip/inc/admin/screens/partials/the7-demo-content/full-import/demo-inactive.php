<div class="dt-dummy-controls-block">
	<p><?php echo wp_kses( sprintf( __( 'Please <a href="%s">register</a> the theme to install this demo.', 'the7mk2' ), admin_url( 'admin.php?page=the7-dashboard' ) ), array( 'a' => array( 'href' => true ) ) )?></p>
</div>